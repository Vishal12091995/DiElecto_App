import React, { createContext, useContext, useState } from "react";

export const LanguageContext = createContext();

export const getLanguageValue = () => {
  const value = useContext(LanguageContext);
  return value;
};

export const LanguageContextProvider = ({ children }) => {
  const [language, setLanguage] = useState("English");

  return (
    <LanguageContext.Provider value={{ language, setLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};

export default LanguageContextProvider;
