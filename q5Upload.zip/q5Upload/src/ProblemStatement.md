### Debug the react app to fix issues with rendering and custom hooks.

The Dialecto app has been refactored to use custom providers and hooks, but the components are not rendering and the custom hooks are not working as expected.

Debug the app to fix these issues.

Output:
<img src="https://res.cloudinary.com/dl26pbek4/image/upload/v1678269129/cn-gifs/dialect-app_ftq0sd.gif"/>
