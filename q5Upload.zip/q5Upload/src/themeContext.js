import React, { createContext, useContext, useState } from "react";

export const ThemeContext = createContext();

export const getThemeValue = () => {
  const value = useContext(ThemeContext);
  return value;
};

export const ThemeContextProvider = ({ children }) => {
  const [theme, setTheme] = useState("light");

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export default ThemeContextProvider;
